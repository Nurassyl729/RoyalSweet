
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './store';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Catalog from './pages/Catalog';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Admin from './pages/Admin';
import Auth from './pages/Auth';
import Profile from './pages/Profile';

const App: React.FC = () => {
  return (
    <AppProvider>
      <Router>
        <div className="min-h-screen flex flex-col selection:bg-[#E6B860] selection:text-white relative overflow-x-hidden">
          {/* Decorative Brandbook Elements */}
          <div className="fixed -top-24 -left-24 w-96 h-96 bg-[#AAB080]/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>
          <div className="fixed -bottom-48 -right-24 w-[32rem] h-[32rem] bg-[#F6D989]/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>
          
          <Navbar />
          <main className="flex-grow pt-24">
            <Routes>
              {/* Core pages */}
              <Route path="/" element={<Catalog />} />
              <Route path="/product/:id" element={<ProductDetail />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/profile" element={<Profile />} />
              
              {/* Hidden Management portal */}
              <Route path="/rs-internal-portal" element={<Admin />} />
              
              {/* Catch all back to catalog */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </AppProvider>
  );
};

export default App;
