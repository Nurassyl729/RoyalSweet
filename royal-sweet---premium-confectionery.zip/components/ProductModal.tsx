
import React from 'react';
import { Product } from '../types';
import { useStore } from '../store';

interface ProductModalProps {
  product: Product;
  isOpen: boolean;
  onClose: () => void;
}

const ProductModal: React.FC<ProductModalProps> = ({ product, isOpen, onClose }) => {
  // Use lp from useStore for localizing strings
  const { addToCart, reviews, lp } = useStore();
  const productReviews = reviews.filter(r => r.product_id === product.id);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-[#2E4032]/40 backdrop-blur-sm" onClick={onClose}></div>
      <div className="bg-[#FCF9F2] w-full max-w-4xl max-h-[90vh] overflow-y-auto relative rounded-3xl shadow-2xl flex flex-col md:flex-row">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 z-10 p-2 text-[#2E4032] hover:text-[#E6B860] transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="w-full md:w-1/2 p-4 md:p-8">
          <img 
            src={product.image} 
            // Localize alt text
            alt={lp(product.name)} 
            className="w-full aspect-square object-cover rounded-2xl shadow-lg"
          />
        </div>

        <div className="w-full md:w-1/2 p-8 md:pl-0 flex flex-col">
          {/* Localize product name */}
          <h2 className="text-4xl font-alice text-[#2E4032] mb-2">{lp(product.name)}</h2>
          <p className="text-[#E6B860] text-2xl mb-6">{product.price.toLocaleString()} ₸</p>
          
          <div className="space-y-4 mb-8">
            <p className="text-[#2E4032]/80 leading-relaxed italic">
              {/* Localize product description */}
              {lp(product.description)}
            </p>
            <p className="text-[#2E4032] leading-relaxed">
              {/* Localize product long description with fallback */}
              {lp(product.longDescription) || "This exquisite creation represents the pinnacle of our craftsmanship, prepared using traditional methods and only the finest ingredients sourced globally."}
            </p>
          </div>

          <button 
            onClick={() => {
              addToCart(product);
              onClose();
            }}
            className="w-full bg-[#2E4032] text-[#FCF9F2] py-4 rounded-xl font-semibold tracking-widest uppercase hover:bg-[#E6B860] transition-all duration-300 shadow-lg shadow-[#2E4032]/10 mb-8"
          >
            Add to your collection
          </button>

          <div className="border-t border-[#AAB080]/20 pt-8 mt-auto">
            <h4 className="text-xl font-alice text-[#2E4032] mb-4">Patient Reviews</h4>
            {productReviews.length > 0 ? (
              <div className="space-y-4">
                {productReviews.map(review => (
                  <div key={review.id} className="bg-white/50 p-4 rounded-lg">
                    <p className="font-medium text-sm mb-1">{review.name}</p>
                    <p className="text-xs text-[#2E4032]/70 italic">"{review.text}"</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-[#AAB080] italic">No reviews yet for this masterpiece. Be the first to share your experience.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductModal;
