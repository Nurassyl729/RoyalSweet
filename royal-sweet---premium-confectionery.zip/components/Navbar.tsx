
import { Link, useLocation } from 'react-router-dom';
import { useStore } from '../store';

const Navbar: React.FC = () => {
  const { cart, language, setLanguage, t, currentUser } = useStore();
  const location = useLocation();
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const languages: ('EN' | 'RU' | 'KZ')[] = ['EN', 'RU', 'KZ'];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#FCF9F2]/90 backdrop-blur-md border-b border-[#AAB080]/10 py-5">
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <Link to="/" className="flex items-center space-x-3 group">
          <div className="relative flex items-center justify-center w-12 h-10">
             <svg viewBox="0 0 100 70" className="w-full h-full fill-[#2E4032] transition-transform group-hover:scale-105 duration-500">
               {/* Central Circle */}
               <circle cx="50" cy="28" r="20" />
               {/* Triangles pointing towards the center */}
               <path d="M10 18 L32 28 L10 38 Z" />
               <path d="M90 18 L68 28 L90 38 Z" />
               {/* Bottom Bar */}
               <rect x="10" y="55" width="80" height="12" />
             </svg>
          </div>
          <span className="text-2xl font-alice tracking-tight text-[#2E4032]">
            Royal Sweet
          </span>
        </Link>

        <div className="hidden md:flex items-center space-x-12">
          <Link
            to="/"
            className={`text-[11px] tracking-[0.2em] uppercase font-bold transition-all hover:text-[#E6B860] relative group ${
              location.pathname === '/' ? 'text-[#E6B860]' : 'text-[#2E4032]'
            }`}
          >
            {t('collections')}
            <span className={`absolute -bottom-1 left-0 w-0 h-[1px] bg-[#E6B860] transition-all group-hover:w-full ${location.pathname === '/' ? 'w-full' : ''}`}></span>
          </Link>

          <Link
            to={currentUser ? "/profile" : "/auth"}
            className={`text-[11px] tracking-[0.2em] uppercase font-bold transition-all hover:text-[#E6B860] relative group ${
              location.pathname === '/profile' || location.pathname === '/auth' ? 'text-[#E6B860]' : 'text-[#2E4032]'
            }`}
          >
            {currentUser ? currentUser.name.split(' ')[0] : t('login')}
            <span className={`absolute -bottom-1 left-0 w-0 h-[1px] bg-[#E6B860] transition-all group-hover:w-full ${location.pathname === '/profile' || location.pathname === '/auth' ? 'w-full' : ''}`}></span>
          </Link>

          <Link
            to="/rs-internal-portal"
            className={`text-[11px] tracking-[0.2em] uppercase font-bold transition-all hover:text-[#E6B860] relative group ${
              location.pathname === '/rs-internal-portal' ? 'text-[#E6B860]' : 'text-[#2E4032]'
            }`}
          >
            {t('admin')}
            <span className={`absolute -bottom-1 left-0 w-0 h-[1px] bg-[#E6B860] transition-all group-hover:w-full ${location.pathname === '/rs-internal-portal' ? 'w-full' : ''}`}></span>
          </Link>

          <div className="flex items-center space-x-4 border-l border-[#AAB080]/20 pl-12">
            {languages.map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`text-[10px] tracking-widest font-bold transition-colors ${
                  language === lang ? 'text-[#E6B860]' : 'text-[#AAB080] hover:text-[#2E4032]'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center space-x-8">
          <Link to="/cart" className="relative p-2 group">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#2E4032] transition-transform group-hover:scale-110" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 bg-[#E6B860] text-white text-[9px] font-bold h-4 w-4 flex items-center justify-center rounded-full border border-[#FCF9F2] shadow-sm animate-bounce">
                {cartCount}
              </span>
            )}
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
