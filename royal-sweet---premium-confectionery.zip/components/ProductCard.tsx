
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import { useStore } from '../store';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart, lp, t } = useStore();
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="group relative bg-white rounded-2xl overflow-hidden transition-all duration-500 hover:shadow-xl hover:shadow-[#AAB080]/10 border border-[#AAB080]/10"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link to={`/product/${product.id}`} className="block aspect-square overflow-hidden cursor-pointer">
        <img 
          src={product.image} 
          alt={lp(product.name)} 
          className={`w-full h-full object-cover transition-transform duration-1000 ${isHovered ? 'scale-110' : 'scale-100'}`}
        />
      </Link>

      <div className="p-6 text-center">
        <h3 className="text-xl font-alice text-[#2E4032] mb-1">{lp(product.name)}</h3>
        <p className="text-sm text-[#AAB080] mb-4 line-clamp-2 min-h-[40px] leading-relaxed">
          {lp(product.description)}
        </p>
        <div className="flex items-center justify-between mt-4">
          <span className="text-lg font-medium text-[#2E4032]">
            {product.price.toLocaleString()} ₸
          </span>
          <button 
            onClick={(e) => {
              e.preventDefault();
              addToCart(product);
            }}
            className="bg-[#E6B860] hover:bg-[#2E4032] text-white px-5 py-2 rounded-full text-[10px] font-bold tracking-widest uppercase transition-all duration-300 shadow-sm"
          >
            {t('addToCart')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
