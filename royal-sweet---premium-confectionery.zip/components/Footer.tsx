
import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';

const Footer: React.FC = () => {
  const { t } = useStore();
  return (
    <footer className="bg-[#2E4032] text-[#FCF9F2] py-20">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="md:col-span-1">
          <h2 className="text-3xl font-alice mb-4">Royal Sweet</h2>
          <p className="text-[#AAB080] text-sm leading-relaxed max-w-xs italic">
            {t('catalogSub')}
          </p>
        </div>
        
        <div>
          <h4 className="font-alice text-xl mb-6">Explore</h4>
          <ul className="space-y-4 text-sm text-[#AAB080]">
            <li><Link to="/" className="hover:text-[#E6B860] transition-colors">{t('collections')}</Link></li>
            <li><Link to="/" className="hover:text-[#E6B860] transition-colors">{t('reflections')}</Link></li>
            <li><Link to="/" className="hover:text-[#E6B860] transition-colors">Our Story</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-alice text-xl mb-6">Support</h4>
          <ul className="space-y-4 text-sm text-[#AAB080]">
            <li><Link to="/" className="hover:text-[#E6B860] transition-colors">Contact Us</Link></li>
            <li><Link to="/" className="hover:text-[#E6B860] transition-colors">Delivery Policy</Link></li>
            <li><Link to="/" className="hover:text-[#E6B860] transition-colors">Privacy</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-alice text-xl mb-6">Newsletter</h4>
          <p className="text-xs text-[#AAB080] mb-4">Receive invitations to new collection unveilings.</p>
          <div className="flex">
            <input 
              type="email" 
              placeholder="Your email" 
              className="bg-transparent border-b border-[#AAB080] text-[#FCF9F2] py-2 text-sm focus:outline-none w-full"
            />
            <button className="ml-4 text-[#E6B860] hover:text-white transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </div>
          {/* Subtle Admin Access */}
          <div className="mt-8">
            <Link to="/rs-internal-portal" className="text-[10px] uppercase tracking-widest text-[#AAB080]/30 hover:text-[#E6B860] transition-colors">
              Management Portal
            </Link>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 mt-20 pt-8 border-t border-white/10 text-center text-[10px] tracking-[0.2em] uppercase text-[#AAB080]">
        © {new Date().getFullYear()} Royal Sweet — {t('slogan')}.
      </div>
    </footer>
  );
};

export default Footer;
