
export interface MultilingualString {
  EN: string;
  RU: string;
  KZ: string;
}

export interface Category {
  id: number;
  name: MultilingualString;
}

export interface User {
  id: number;
  name: string;
  email: string;
  password?: string;
  phone?: string;
  kaspi_number?: string;
  address?: string;
}

export interface Product {
  id: number;
  name: MultilingualString;
  description: MultilingualString;
  longDescription: MultilingualString;
  price: number;
  image: string;
  categoryId?: number;
}

export interface OrderItem {
  id: number;
  product_id: number;
  quantity: number;
  price: number;
  name: string;
}

export interface Order {
  id: number;
  user_id?: number; // Optional user association
  customer_name: string;
  phone: string;
  kaspi_number: string;
  address: string;
  total_price: number;
  created_at: string;
  items: OrderItem[];
}

export interface Review {
  id: number;
  product_id: number;
  name: string;
  text: string;
  created_at: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
