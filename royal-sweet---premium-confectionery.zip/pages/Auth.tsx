
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';

const Auth: React.FC = () => {
  const { login, register, t } = useStore();
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    kaspi_number: '',
    address: ''
  });
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (isLogin) {
      const success = login(formData.email, formData.password);
      if (success) {
        navigate('/profile');
      } else {
        setError('Invalid credentials');
      }
    } else {
      register(formData);
      navigate('/profile');
    }
  };

  return (
    <div className="py-24 px-6 flex items-center justify-center">
      <div className="bg-white p-12 rounded-[3rem] shadow-2xl border border-[#AAB080]/10 max-w-md w-full animate-fade">
        <h2 className="text-4xl font-alice text-[#2E4032] mb-8 text-center">
          {isLogin ? t('login') : 'Join Royal Sweet'}
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {!isLogin && (
            <input 
              required
              placeholder="Full Name"
              className="w-full bg-[#FCF9F2] border border-[#AAB080]/20 rounded-2xl p-4 focus:outline-none focus:border-[#E6B860] transition-colors"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
            />
          )}
          <input 
            required
            type="email"
            placeholder="Email Address"
            className="w-full bg-[#FCF9F2] border border-[#AAB080]/20 rounded-2xl p-4 focus:outline-none focus:border-[#E6B860] transition-colors"
            value={formData.email}
            onChange={e => setFormData({...formData, email: e.target.value})}
          />
          <input 
            required
            type="password"
            placeholder="Password"
            className="w-full bg-[#FCF9F2] border border-[#AAB080]/20 rounded-2xl p-4 focus:outline-none focus:border-[#E6B860] transition-colors"
            value={formData.password}
            onChange={e => setFormData({...formData, password: e.target.value})}
          />
          {!isLogin && (
            <>
              <input 
                placeholder="Kaspi Number (Optional)"
                className="w-full bg-[#FCF9F2] border border-[#AAB080]/20 rounded-2xl p-4 focus:outline-none focus:border-[#E6B860] transition-colors"
                value={formData.kaspi_number}
                onChange={e => setFormData({...formData, kaspi_number: e.target.value})}
              />
              <textarea 
                placeholder="Default Address (Optional)"
                className="w-full bg-[#FCF9F2] border border-[#AAB080]/20 rounded-2xl p-4 focus:outline-none focus:border-[#E6B860] transition-colors h-24 resize-none"
                value={formData.address}
                onChange={e => setFormData({...formData, address: e.target.value})}
              />
            </>
          )}

          {error && <p className="text-red-400 text-xs text-center font-bold uppercase tracking-widest">{error}</p>}

          <button type="submit" className="w-full bg-[#2E4032] text-white py-5 rounded-2xl font-bold tracking-[0.2em] uppercase hover:bg-[#E6B860] transition-all shadow-xl">
            {isLogin ? t('login') : 'Register'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-[11px] text-[#AAB080] uppercase tracking-widest font-bold hover:text-[#2E4032] transition-colors"
          >
            {isLogin ? "Don't have an account? Create one" : "Already a patron? Sign in"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
