
import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';

const Cart: React.FC = () => {
  const { cart, removeFromCart, updateQuantity, t, lp } = useStore();
  const total = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  if (cart.length === 0) {
    return (
      <div className="py-40 px-6 text-center animate-in fade-in slide-in-from-bottom duration-700">
        <h2 className="text-4xl font-alice text-[#2E4032] mb-6">{t('emptyCart')}</h2>
        <p className="text-[#AAB080] mb-10">{t('browseCollection')}</p>
        <Link to="/" className="px-10 py-4 bg-[#E6B860] text-white rounded-full font-semibold tracking-widest uppercase hover:bg-[#2E4032] transition-colors">
          {t('collections')}
        </Link>
      </div>
    );
  }

  return (
    <div className="py-20 px-6 animate-in fade-in slide-in-from-bottom duration-700">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-alice text-[#2E4032] mb-12">{t('yourCollection')}</h1>
        
        <div className="space-y-8 mb-16">
          {cart.map(item => (
            <div key={item.product.id} className="flex flex-col sm:flex-row items-center gap-8 bg-white p-6 rounded-2xl border border-[#AAB080]/10 transition-shadow hover:shadow-lg">
              <img src={item.product.image} className="w-24 h-24 object-cover rounded-xl" alt={lp(item.product.name)} />
              
              <div className="flex-grow text-center sm:text-left">
                <h3 className="text-xl font-alice text-[#2E4032]">{lp(item.product.name)}</h3>
                <p className="text-[#E6B860] font-medium">{item.product.price.toLocaleString()} ₸</p>
              </div>

              <div className="flex items-center space-x-4 bg-[#FCF9F2] px-4 py-2 rounded-full border border-[#AAB080]/20">
                <button onClick={() => updateQuantity(item.product.id, -1)} className="text-[#AAB080] hover:text-[#2E4032] transition-colors">-</button>
                <span className="w-8 text-center font-medium">{item.quantity}</span>
                <button onClick={() => updateQuantity(item.product.id, 1)} className="text-[#AAB080] hover:text-[#2E4032] transition-colors">+</button>
              </div>

              <div className="text-right sm:w-32">
                <p className="font-semibold text-[#2E4032]">{(item.product.price * item.quantity).toLocaleString()} ₸</p>
                <button 
                  onClick={() => removeFromCart(item.product.id)}
                  className="text-xs uppercase tracking-widest text-[#AAB080] hover:text-red-400 mt-2 transition-colors"
                >
                  {t('remove')}
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-[#FCF9F2] p-8 rounded-3xl border border-[#AAB080]/20">
          <div className="flex justify-between items-center mb-8">
            <span className="text-[#AAB080] tracking-widest uppercase text-sm">{t('totalValue')}</span>
            <span className="text-3xl font-alice text-[#2E4032]">{total.toLocaleString()} ₸</span>
          </div>
          <Link to="/checkout" className="block w-full text-center bg-[#2E4032] text-white py-5 rounded-xl font-semibold tracking-widest uppercase hover:bg-[#E6B860] transition-all duration-300 shadow-xl shadow-[#2E4032]/10">
            {t('proceedCheckout')}
          </Link>
          <p className="mt-4 text-center text-xs text-[#AAB080] italic">
            Complimentary premium packaging included with every order.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Cart;
