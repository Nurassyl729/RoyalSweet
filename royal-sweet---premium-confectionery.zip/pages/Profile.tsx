
import React from 'react';
import { Navigate, Link } from 'react-router-dom';
import { useStore } from '../store';

const Profile: React.FC = () => {
  const { currentUser, orders, logout, t } = useStore();

  if (!currentUser) return <Navigate to="/auth" />;

  const myOrders = orders.filter(o => o.user_id === currentUser.id);

  return (
    <div className="py-20 px-6 max-w-6xl mx-auto animate-fade">
      <div className="flex flex-col md:flex-row gap-16">
        {/* User Sidebar */}
        <div className="w-full md:w-1/3 space-y-8">
          <div className="bg-white p-10 rounded-[3rem] shadow-xl border border-[#AAB080]/10 text-center">
            <div className="w-24 h-24 bg-[#F6D989] rounded-full flex items-center justify-center text-4xl text-[#2E4032] font-alice mx-auto mb-6 shadow-inner">
              {currentUser.name.charAt(0)}
            </div>
            <h2 className="text-3xl font-alice text-[#2E4032] mb-2">{currentUser.name}</h2>
            <p className="text-[#AAB080] text-sm mb-8">{currentUser.email}</p>
            
            <div className="space-y-4 pt-8 border-t border-[#AAB080]/10 text-left">
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-widest text-[#AAB080] font-bold">Preferred Kaspi</span>
                <span className="text-[#2E4032]">{currentUser.kaspi_number || 'Not set'}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-widest text-[#AAB080] font-bold">Saved Address</span>
                <span className="text-[#2E4032] text-sm italic">{currentUser.address || 'Not set'}</span>
              </div>
            </div>

            <button 
              onClick={logout}
              className="mt-12 w-full border border-red-200 text-red-400 py-3 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-red-50 transition-all"
            >
              {t('logout')}
            </button>
          </div>
        </div>

        {/* Order History */}
        <div className="flex-grow">
          <h2 className="text-4xl font-alice text-[#2E4032] mb-12">{t('history')}</h2>
          
          <div className="space-y-8">
            {myOrders.length > 0 ? (
              myOrders.map(order => (
                <div key={order.id} className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-[#AAB080]/10 transition-all hover:shadow-md">
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-xs font-mono text-[#AAB080]">#{order.id.toString().slice(-6)}</span>
                    <span className="text-[10px] uppercase tracking-widest text-[#AAB080]">{new Date(order.created_at).toLocaleDateString()}</span>
                  </div>
                  
                  <div className="space-y-3 mb-6">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-sm">
                        <span className="text-[#2E4032]">{item.name} <span className="text-[#AAB080]">x{item.quantity}</span></span>
                        <span className="font-medium">{(item.price * item.quantity).toLocaleString()} ₸</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex justify-between items-center pt-6 border-t border-gray-50">
                    <span className="text-sm font-bold text-[#AAB080] uppercase tracking-widest">Total Value</span>
                    <span className="text-2xl font-alice text-[#E6B860]">{order.total_price.toLocaleString()} ₸</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-20 text-center bg-white rounded-[3rem] border border-dashed border-[#AAB080]/30">
                <p className="text-[#AAB080] font-alice text-2xl mb-8">Your collection history is waiting to be written.</p>
                <Link to="/" className="inline-block px-10 py-4 bg-[#2E4032] text-white rounded-full font-bold uppercase tracking-widest hover:bg-[#E6B860] transition-colors">
                  Explore Collections
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
