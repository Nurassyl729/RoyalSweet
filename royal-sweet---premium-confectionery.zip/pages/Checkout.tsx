
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';

const Checkout: React.FC = () => {
  const { cart, placeOrder, t, lp, currentUser } = useStore();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    kaspi_number: '',
    address: ''
  });
  const [isOrdered, setIsOrdered] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name || '',
        phone: currentUser.phone || '',
        kaspi_number: currentUser.kaspi_number || '',
        address: currentUser.address || ''
      });
    }
  }, [currentUser]);

  const total = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    placeOrder(formData);
    setIsOrdered(true);
    setTimeout(() => {
      navigate('/');
    }, 6000);
  };

  if (isOrdered) {
    return (
      <div className="py-40 px-6 text-center animate-fade">
        <div className="max-w-2xl mx-auto bg-white p-16 rounded-[4rem] shadow-2xl border border-[#F6D989]">
          <div className="w-24 h-24 bg-[#E6B860] rounded-full flex items-center justify-center mx-auto mb-10 shadow-lg">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-5xl font-alice text-[#2E4032] mb-8">{t('orderSuccess')}</h2>
          <p className="text-xl text-[#2E4032]/80 leading-relaxed mb-8">
            {t('paymentQueued')} <span className="font-bold text-[#E6B860]">{formData.kaspi_number}</span>.
          </p>
          <div className="p-6 bg-[#FCF9F2] rounded-3xl text-[#AAB080] text-sm italic border border-[#AAB080]/10 mb-8">
            {t('checkNotifications')}
          </div>
          <p className="text-xs text-[#AAB080] tracking-widest uppercase">Preparing your collection with care...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="py-24 px-6 animate-fade">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-24">
        <div>
          <h1 className="text-5xl font-alice text-[#2E4032] mb-12">{t('proceedCheckout')}</h1>
          <form onSubmit={handleSubmit} className="space-y-10">
            <div className="space-y-3">
              <label className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#AAB080]">{t('fullName')}</label>
              <input 
                required
                type="text" 
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
                placeholder="..." 
                className="w-full bg-white border-b-2 border-[#AAB080]/10 p-5 text-lg focus:outline-none focus:border-[#E6B860] transition-colors"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-3">
                <label className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#AAB080]">{t('contactPhone')}</label>
                <input 
                  required
                  type="tel" 
                  value={formData.phone}
                  onChange={e => setFormData({...formData, phone: e.target.value})}
                  placeholder="+7 (___) ___ __ __" 
                  className="w-full bg-white border-b-2 border-[#AAB080]/10 p-5 text-lg focus:outline-none focus:border-[#E6B860] transition-colors"
                />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#AAB080]">{t('kaspiNumber')}</label>
                <input 
                  required
                  type="tel" 
                  value={formData.kaspi_number}
                  onChange={e => setFormData({...formData, kaspi_number: e.target.value})}
                  placeholder="..." 
                  className="w-full bg-white border-b-2 border-[#AAB080]/10 p-5 text-lg focus:outline-none focus:border-[#E6B860] transition-colors"
                />
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] uppercase tracking-[0.3em] font-bold text-[#AAB080]">{t('deliveryAddress')}</label>
              <textarea 
                required
                rows={3}
                value={formData.address}
                onChange={e => setFormData({...formData, address: e.target.value})}
                placeholder="..." 
                className="w-full bg-white border-b-2 border-[#AAB080]/10 p-5 text-lg focus:outline-none focus:border-[#E6B860] transition-colors resize-none"
              ></textarea>
            </div>

            <button type="submit" className="w-full bg-[#E6B860] text-white py-7 rounded-[2rem] font-bold tracking-[0.2em] uppercase hover:bg-[#2E4032] transition-all duration-500 shadow-2xl shadow-[#E6B860]/30 transform hover:-translate-y-1">
              {t('completeOrder')} — {total.toLocaleString()} ₸
            </button>
          </form>
        </div>

        <div className="lg:sticky lg:top-32 h-fit bg-[#2E4032] text-[#FCF9F2] p-12 rounded-[4rem] shadow-2xl overflow-hidden relative">
          <div className="absolute top-0 right-0 p-10 opacity-10 pointer-events-none">
            <svg viewBox="0 0 100 100" className="w-32 h-32 text-white">
              <circle cx="50" cy="50" r="40" fill="currentColor" />
            </svg>
          </div>
          
          <h3 className="text-3xl font-alice mb-10 border-b border-white/10 pb-6">Your Selections</h3>
          <div className="space-y-6 mb-12">
            {cart.map(item => (
              <div key={item.product.id} className="flex justify-between items-center text-sm">
                <div className="flex flex-col">
                  <span className="font-bold">{lp(item.product.name)}</span>
                  <span className="text-xs text-[#AAB080]">Quantity: {item.quantity}</span>
                </div>
                <span className="font-alice text-lg">{(item.product.price * item.quantity).toLocaleString()} ₸</span>
              </div>
            ))}
          </div>
          
          <div className="border-t border-white/20 pt-8 flex justify-between items-center mb-10">
            <span className="text-xl font-alice">{t('totalValue')}</span>
            <span className="text-4xl font-alice text-[#E6B860]">{total.toLocaleString()} ₸</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
