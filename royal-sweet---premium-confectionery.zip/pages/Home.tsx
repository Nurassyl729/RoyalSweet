
import React from 'react';
import { Navigate } from 'react-router-dom';

/**
 * DEPRECATED: Home page content has been merged into Catalog 
 * as the new starting point of the application.
 */
const Home: React.FC = () => {
  return <Navigate to="/" replace />;
};

export default Home;
