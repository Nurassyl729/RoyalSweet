
import React, { useState } from 'react';
import { useStore } from '../store';

const Reviews: React.FC = () => {
  // Use lp from useStore for localizing product names in dropdown
  const { reviews, addReview, products, lp } = useStore();
  const [newReview, setNewReview] = useState({ name: '', text: '', product_id: products[0]?.id || 1 });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newReview.name && newReview.text) {
      addReview(newReview);
      setNewReview({ ...newReview, name: '', text: '' });
    }
  };

  return (
    <div className="py-20 px-6 max-w-7xl mx-auto">
      <div className="text-center mb-20">
        <h1 className="text-5xl font-alice text-[#2E4032] mb-4">Reflections of Taste</h1>
        <p className="text-[#AAB080] uppercase tracking-[0.2em] text-xs">Stories shared by our esteemed patrons</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        <div className="lg:col-span-2 space-y-8">
          {reviews.length > 0 ? (
            reviews.map(review => (
              <div key={review.id} className="bg-white p-10 rounded-3xl border border-[#AAB080]/10 shadow-sm transition-all hover:shadow-md">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-[#F6D989] rounded-full flex items-center justify-center text-[#2E4032] font-bold text-xl mr-4">
                    {review.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#2E4032]">{review.name}</h4>
                    <span className="text-xs text-[#AAB080]">{new Date(review.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
                <p className="text-lg text-[#2E4032]/80 leading-relaxed font-light italic">"{review.text}"</p>
              </div>
            ))
          ) : (
            <div className="bg-white p-20 rounded-[3rem] text-center border border-[#AAB080]/10">
              <p className="text-xl text-[#AAB080] font-alice">Your story could be the first one shared.</p>
            </div>
          )}
        </div>

        <div className="bg-[#FCF9F2] p-10 rounded-[3rem] h-fit sticky top-32 border border-[#AAB080]/20">
          <h3 className="text-3xl font-alice mb-8 text-[#2E4032]">Share Your Moment</h3>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#AAB080]">Your Name</label>
              <input 
                required
                type="text" 
                value={newReview.name}
                onChange={e => setNewReview({...newReview, name: e.target.value})}
                className="w-full bg-white border border-[#AAB080]/20 rounded-xl p-4 focus:outline-none focus:border-[#E6B860]"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#AAB080]">Collection</label>
              <select 
                className="w-full bg-white border border-[#AAB080]/20 rounded-xl p-4 focus:outline-none focus:border-[#E6B860]"
                value={newReview.product_id}
                onChange={e => setNewReview({...newReview, product_id: Number(e.target.value)})}
              >
                {/* Localize product name in the selection dropdown */}
                {products.map(p => <option key={p.id} value={p.id}>{lp(p.name)}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#AAB080]">Your Thoughts</label>
              <textarea 
                required
                rows={4}
                value={newReview.text}
                onChange={e => setNewReview({...newReview, text: e.target.value})}
                className="w-full bg-white border border-[#AAB080]/20 rounded-xl p-4 focus:outline-none focus:border-[#E6B860] resize-none"
              ></textarea>
            </div>
            <button type="submit" className="w-full bg-[#2E4032] text-white py-4 rounded-xl font-bold tracking-[0.2em] uppercase hover:bg-[#E6B860] transition-colors shadow-lg">
              Post Review
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Reviews;
