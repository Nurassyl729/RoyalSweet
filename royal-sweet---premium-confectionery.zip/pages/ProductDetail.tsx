
import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useStore } from '../store';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { products, reviews, addReview, addToCart, t, lp } = useStore();
  const product = products.find(p => p.id === Number(id));
  
  const [reviewForm, setReviewForm] = useState({ name: '', text: '' });
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <div className="py-40 text-center">
        <h2 className="text-3xl font-alice text-[#2E4032]">Delicacy not found.</h2>
        <Link to="/" className="text-[#E6B860] mt-4 block uppercase tracking-widest font-bold">Return to Collection</Link>
      </div>
    );
  }

  const productReviews = reviews.filter(r => r.product_id === product.id);

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (reviewForm.name && reviewForm.text) {
      addReview({
        product_id: product.id,
        name: reviewForm.name,
        text: reviewForm.text
      });
      setReviewForm({ name: '', text: '' });
    }
  };

  return (
    <div className="py-20 px-6 max-w-7xl mx-auto animate-fade">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
        {/* Gallery */}
        <div className="relative group">
          <img 
            src={product.image} 
            alt={lp(product.name)} 
            className="w-full aspect-square object-cover rounded-[3rem] shadow-2xl transition-transform duration-700 group-hover:scale-[1.02]"
          />
        </div>

        {/* Content */}
        <div className="space-y-12">
          <div>
            <h1 className="text-6xl font-alice text-[#2E4032] mb-4">{lp(product.name)}</h1>
            <p className="text-4xl text-[#E6B860] font-alice">{product.price.toLocaleString()} ₸</p>
          </div>

          <div className="space-y-6">
            <p className="text-xl text-[#2E4032]/80 leading-relaxed italic border-l-2 border-[#E6B860] pl-6 font-light">
              {lp(product.description)}
            </p>
            <p className="text-lg text-[#2E4032] leading-relaxed font-light">
              {lp(product.longDescription)}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6 pt-4">
            <div className="flex items-center space-x-6 bg-white border border-[#AAB080]/20 px-8 py-4 rounded-full shadow-sm">
               <button onClick={() => setQuantity(q => Math.max(1, q-1))} className="text-2xl text-[#AAB080] hover:text-[#2E4032]">-</button>
               <span className="text-xl font-bold w-10 text-center">{quantity}</span>
               <button onClick={() => setQuantity(q => q+1)} className="text-2xl text-[#AAB080] hover:text-[#2E4032]">+</button>
            </div>
            <button 
              onClick={() => addToCart(product, quantity)}
              className="flex-grow w-full bg-[#2E4032] text-white py-6 rounded-3xl font-bold tracking-[0.2em] uppercase hover:bg-[#E6B860] transition-all duration-500 shadow-xl shadow-[#2E4032]/20"
            >
              {t('addToCart')}
            </button>
          </div>

          {/* Reviews Section */}
          <div className="pt-20 border-t border-[#AAB080]/20">
            <div className="flex justify-between items-baseline mb-12">
              <h2 className="text-4xl font-alice text-[#2E4032]">{t('patronReflections')}</h2>
              <span className="text-[#AAB080] text-sm uppercase tracking-widest">{productReviews.length}</span>
            </div>

            <div className="space-y-10 mb-16">
              {productReviews.length > 0 ? (
                productReviews.map(review => (
                  <div key={review.id} className="bg-white/50 p-8 rounded-3xl border border-[#AAB080]/10">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-10 h-10 bg-[#F6D989] rounded-full flex items-center justify-center font-bold text-[#2E4032]">
                        {review.name.charAt(0)}
                      </div>
                      <span className="font-bold text-[#2E4032]">{review.name}</span>
                      <span className="text-xs text-[#AAB080] ml-auto">{new Date(review.created_at).toLocaleDateString()}</span>
                    </div>
                    <p className="text-[#2E4032]/80 font-light italic leading-relaxed">"{review.text}"</p>
                  </div>
                ))
              ) : (
                <p className="text-[#AAB080] italic py-10 text-center">Your story could be the first reflection of this masterpiece.</p>
              )}
            </div>

            {/* Review Form */}
            <div className="bg-[#FCF9F2] p-10 rounded-[2.5rem] border border-[#AAB080]/20">
              <h3 className="text-2xl font-alice text-[#2E4032] mb-8">{t('shareExperience')}</h3>
              <form onSubmit={handleReviewSubmit} className="space-y-6">
                <input 
                  required
                  placeholder="Your Name"
                  className="w-full bg-white border border-[#AAB080]/10 rounded-2xl p-4 focus:outline-none focus:border-[#E6B860]"
                  value={reviewForm.name}
                  onChange={e => setReviewForm({...reviewForm, name: e.target.value})}
                />
                <textarea 
                  required
                  rows={4}
                  placeholder="Your thoughts..."
                  className="w-full bg-white border border-[#AAB080]/10 rounded-2xl p-4 focus:outline-none focus:border-[#E6B860] resize-none"
                  value={reviewForm.text}
                  onChange={e => setReviewForm({...reviewForm, text: e.target.value})}
                ></textarea>
                <button type="submit" className="w-full bg-white border-2 border-[#2E4032] text-[#2E4032] py-4 rounded-2xl font-bold uppercase tracking-widest hover:bg-[#2E4032] hover:text-white transition-all">
                  {t('postReflection')}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
