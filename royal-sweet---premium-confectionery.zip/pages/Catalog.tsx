
import React, { useState } from 'react';
import { useStore } from '../store';
import ProductCard from '../components/ProductCard';

const Catalog: React.FC = () => {
  const { products, categories, t, lp } = useStore();
  const [filterId, setFilterId] = useState<number | 'All'>('All');

  const filteredProducts = filterId === 'All' 
    ? products 
    : products.filter(p => p.categoryId === filterId);

  return (
    <div className="animate-in fade-in duration-1000">
      <section className="bg-[#FCF9F2] pt-10 pb-24 px-6 relative overflow-hidden">
        {/* Background Logo Pattern */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[600px] h-[600px] opacity-[0.03] pointer-events-none">
          <svg viewBox="0 0 100 100" className="w-full h-full text-[#2E4032]">
            <circle cx="50" cy="40" r="22" fill="currentColor" />
            <path d="M10 30 L32 40 L10 50 Z" fill="currentColor" />
            <path d="M90 30 L68 40 L90 50 Z" fill="currentColor" />
            <rect x="10" y="65" width="80" height="12" fill="currentColor" />
          </svg>
        </div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <span className="text-[10px] uppercase tracking-[0.4em] font-bold text-[#AAB080] mb-6 block">
            {t('descriptor')}
          </span>
          <h1 className="text-5xl md:text-7xl font-alice text-[#2E4032] mb-8 leading-tight">
            {t('catalogTitle')}
          </h1>
          <p className="text-lg text-[#2E4032]/70 max-w-2xl mx-auto leading-relaxed italic mb-12">
            {t('catalogSub')}
          </p>
          
          <div className="flex flex-wrap justify-center gap-3 md:gap-4 border-t border-b border-[#AAB080]/10 py-8">
            <button
              onClick={() => setFilterId('All')}
              className={`px-7 py-2.5 rounded-full text-[10px] font-bold tracking-[0.2em] uppercase transition-all duration-500 ${
                filterId === 'All' 
                  ? 'bg-[#2E4032] text-[#FCF9F2] shadow-xl shadow-[#2E4032]/20 scale-105' 
                  : 'bg-white text-[#AAB080] hover:text-[#2E4032] border border-transparent'
              }`}
            >
              {t('all')}
            </button>
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setFilterId(cat.id)}
                className={`px-7 py-2.5 rounded-full text-[10px] font-bold tracking-[0.2em] uppercase transition-all duration-500 ${
                  filterId === cat.id 
                    ? 'bg-[#2E4032] text-[#FCF9F2] shadow-xl shadow-[#2E4032]/20 scale-105' 
                    : 'bg-white text-[#AAB080] hover:text-[#2E4032] border border-transparent'
                }`}
              >
                {lp(cat.name)}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 px-6 bg-white relative">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-12 md:gap-8">
            {filteredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          
          {filteredProducts.length === 0 && (
            <div className="text-center py-40">
              <h3 className="font-alice text-3xl text-[#2E4032]">No products in this selection.</h3>
            </div>
          )}
        </div>
      </section>
      
      <section className="bg-[#2E4032] py-24 px-6 overflow-hidden relative">
         <div className="max-w-4xl mx-auto text-center text-[#FCF9F2] relative z-10">
            <h2 className="text-4xl font-alice mb-8 leading-tight">{t('refinementTitle')}</h2>
            <p className="text-lg opacity-80 leading-relaxed font-light mb-12">
               {t('refinementDesc')}
            </p>
         </div>
      </section>
    </div>
  );
};

export default Catalog;
