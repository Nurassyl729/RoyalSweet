
import React from 'react';

const Contacts: React.FC = () => {
  return (
    <div className="py-20 px-6 max-w-7xl mx-auto">
      <div className="bg-[#2E4032] rounded-[4rem] overflow-hidden flex flex-col lg:flex-row shadow-2xl">
        <div className="w-full lg:w-1/2 p-16 lg:p-24 text-[#FCF9F2]">
          <h1 className="text-5xl font-alice mb-10">Visit Our Salon</h1>
          <div className="space-y-12">
            <div>
              <h4 className="text-[#AAB080] uppercase tracking-widest text-xs font-bold mb-4">Location</h4>
              <p className="text-2xl font-alice leading-relaxed">
                Abay Ave 42, Almaty, <br />
                Republic of Kazakhstan
              </p>
            </div>
            
            <div>
              <h4 className="text-[#AAB080] uppercase tracking-widest text-xs font-bold mb-4">Contact</h4>
              <p className="text-2xl font-alice leading-relaxed">
                +7 (707) 123 45 67 <br />
                salon@royalsweet.kz
              </p>
            </div>

            <div>
              <h4 className="text-[#AAB080] uppercase tracking-widest text-xs font-bold mb-4">Hours</h4>
              <p className="text-2xl font-alice leading-relaxed">
                Mon — Sat: 10:00 - 20:00 <br />
                Sun: 11:00 - 18:00
              </p>
            </div>
          </div>
        </div>

        <div className="w-full lg:w-1/2 relative min-h-[500px]">
          <img 
            src="https://picsum.photos/seed/contact-img/1000/1200" 
            alt="Royal Sweet Boutique" 
            className="absolute inset-0 w-full h-full object-cover"
          />
        </div>
      </div>
      
      <div className="mt-20 text-center">
        <h2 className="text-3xl font-alice text-[#2E4032] mb-6">A question of taste?</h2>
        <p className="text-[#AAB080] mb-10 max-w-xl mx-auto">
          Our concierges are available to assist you in selecting the perfect gesture for your specific occasion.
        </p>
        <button className="px-12 py-5 bg-[#E6B860] text-white rounded-full font-bold tracking-[0.2em] uppercase hover:bg-[#2E4032] transition-all shadow-lg">
          Inquire Privately
        </button>
      </div>
    </div>
  );
};

export default Contacts;
