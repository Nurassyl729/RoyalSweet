
import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../store';
import { MultilingualString } from '../types';

const Admin: React.FC = () => {
  const { 
    products, categories, orders, reviews, users,
    addProduct, deleteProduct, 
    addCategory, deleteCategory, 
    deleteOrder, deleteReview, 
    lp 
  } = useStore();
  
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState(false);
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'reviews' | 'categories' | 'patrons'>('orders');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const authStatus = sessionStorage.getItem('rs_admin_auth');
    if (authStatus === 'true') {
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === '160408') {
      setIsAuthenticated(true);
      setAuthError(false);
      sessionStorage.setItem('rs_admin_auth', 'true');
    } else {
      setAuthError(true);
    }
  };

  const [newProduct, setNewProduct] = useState({
    name: { EN: '', RU: '', KZ: '' },
    price: '',
    categoryId: '',
    description: { EN: '', RU: '', KZ: '' },
    longDescription: { EN: '', RU: '', KZ: '' },
    image: '' // Initialize as empty, will be set by file upload
  });

  const [newCategory, setNewCategory] = useState({
    name: { EN: '', RU: '', KZ: '' }
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewProduct(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.image) {
      alert("Please provide a product photograph.");
      return;
    }
    addProduct({
      name: newProduct.name,
      price: Number(newProduct.price),
      categoryId: newProduct.categoryId ? Number(newProduct.categoryId) : undefined,
      description: newProduct.description,
      longDescription: newProduct.longDescription,
      image: newProduct.image
    });
    setNewProduct({ 
      name: { EN: '', RU: '', KZ: '' }, 
      price: '', 
      categoryId: '',
      description: { EN: '', RU: '', KZ: '' }, 
      longDescription: { EN: '', RU: '', KZ: '' }, 
      image: '' 
    });
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    addCategory({ name: newCategory.name });
    setNewCategory({ name: { EN: '', RU: '', KZ: '' } });
  };

  const updateNewProductField = (field: 'name' | 'description' | 'longDescription', lang: keyof MultilingualString, value: string) => {
    setNewProduct(prev => ({
      ...prev,
      [field]: { ...prev[field], [lang]: value }
    }));
  };

  const updateNewCategoryField = (lang: keyof MultilingualString, value: string) => {
    setNewCategory(prev => ({
      ...prev,
      name: { ...prev.name, [lang]: value }
    }));
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-6">
        <div className="bg-white p-12 rounded-[3rem] shadow-2xl border border-[#AAB080]/10 max-w-md w-full text-center animate-fade">
          <div className="w-16 h-16 bg-[#2E4032] rounded-full flex items-center justify-center mx-auto mb-8 shadow-lg">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[#F6D989]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-3xl font-alice text-[#2E4032] mb-4">Internal Access</h2>
          <form onSubmit={handleLogin} className="space-y-6">
            <input 
              type="password" 
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              placeholder="••••••••" 
              className={`w-full bg-[#FCF9F2] border ${authError ? 'border-red-300' : 'border-[#AAB080]/20'} rounded-2xl p-4 text-center text-lg tracking-widest focus:outline-none focus:border-[#E6B860] transition-colors`}
              required
            />
            {authError && <p className="text-red-400 text-[10px] uppercase tracking-widest font-bold">Incorrect Credential</p>}
            <button type="submit" className="w-full bg-[#2E4032] text-white py-5 rounded-2xl font-bold tracking-[0.2em] uppercase hover:bg-[#E6B860] transition-all shadow-xl">
              Authorize
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-7xl mx-auto animate-fade">
      <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-gray-100 relative">
        <div className="sticky top-0 z-40 flex border-b border-gray-100 bg-[#FCF9F2]/95 backdrop-blur-md overflow-x-auto scrollbar-hide">
          {(['orders', 'products', 'categories', 'reviews', 'patrons'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-12 py-8 text-[11px] font-bold uppercase tracking-[0.3em] transition-all whitespace-nowrap relative ${
                activeTab === tab ? 'text-[#2E4032]' : 'text-[#AAB080] hover:text-[#2E4032]'
              }`}
            >
              {tab}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#2E4032]" />
              )}
            </button>
          ))}
          <button 
            onClick={() => {
              sessionStorage.removeItem('rs_admin_auth');
              setIsAuthenticated(false);
            }}
            className="ml-auto px-12 py-8 text-[11px] font-bold uppercase tracking-[0.3em] text-red-400 hover:text-red-600 transition-colors"
          >
            Logout
          </button>
        </div>

        <div className="p-12 min-h-[60vh]">
          {activeTab === 'patrons' && (
            <div className="space-y-10">
              <h2 className="text-4xl font-alice text-[#2E4032]">Patron Directory</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {users.map(u => (
                  <div key={u.id} className="bg-gray-50 p-8 rounded-3xl border border-gray-100">
                    <div className="flex items-center gap-4 mb-6">
                      <div className="w-12 h-12 bg-[#2E4032] text-[#F6D989] rounded-full flex items-center justify-center font-alice text-xl">
                        {u.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-[#2E4032]">{u.name}</h4>
                        <p className="text-xs text-[#AAB080]">{u.email}</p>
                      </div>
                    </div>
                    <div className="space-y-2 text-xs text-[#2E4032]/70">
                      <p><strong>Kaspi:</strong> {u.kaspi_number || 'N/A'}</p>
                      <p><strong>Address:</strong> {u.address || 'N/A'}</p>
                    </div>
                  </div>
                ))}
                {users.length === 0 && <p className="text-center col-span-full py-20 text-[#AAB080] font-alice text-2xl">No registered patrons yet.</p>}
              </div>
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="space-y-10">
              <h2 className="text-4xl font-alice text-[#2E4032]">Order Registry</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-100 text-[#AAB080] uppercase text-[10px] tracking-widest font-bold">
                      <th className="py-6">ID</th>
                      <th className="py-6">Customer</th>
                      <th className="py-6">Type</th>
                      <th className="py-6">Total</th>
                      <th className="py-6">Date</th>
                      <th className="py-6 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map(order => (
                      <tr key={order.id} className="border-b border-gray-50 text-sm">
                        <td className="py-4 text-xs font-mono text-[#AAB080]">#{order.id.toString().slice(-6)}</td>
                        <td className="py-4 font-bold">{order.customer_name}</td>
                        <td className="py-4">
                          <span className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-widest ${order.user_id ? 'bg-green-50 text-green-600' : 'bg-gray-50 text-[#AAB080]'}`}>
                            {order.user_id ? 'Patron' : 'Guest'}
                          </span>
                        </td>
                        <td className="py-4 font-alice text-lg">{order.total_price.toLocaleString()} ₸</td>
                        <td className="py-4 text-[#AAB080]">{new Date(order.created_at).toLocaleDateString()}</td>
                        <td className="py-4 text-right">
                          <button onClick={() => deleteOrder(order.id)} className="text-red-400 text-xs font-bold uppercase tracking-widest">Delete</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'categories' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              <div className="space-y-8">
                <h2 className="text-4xl font-alice text-[#2E4032]">Product Types</h2>
                <div className="space-y-4">
                  {categories.map(cat => (
                    <div key={cat.id} className="flex items-center justify-between p-6 bg-gray-50 rounded-2xl border border-transparent hover:border-[#AAB080]/20 transition-all">
                      <span className="font-bold text-[#2E4032]">{lp(cat.name)}</span>
                      <button onClick={() => deleteCategory(cat.id)} className="text-red-400 text-xs font-bold uppercase tracking-widest">Delete</button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-[#FCF9F2] p-10 rounded-[2.5rem] border border-[#AAB080]/20">
                <h3 className="text-2xl font-alice text-[#2E4032] mb-8">Add New Category</h3>
                <form onSubmit={handleAddCategory} className="space-y-6">
                  <div className="space-y-4">
                    <label className="text-[10px] uppercase tracking-widest font-bold text-[#AAB080]">Name (EN / RU / KZ)</label>
                    <input placeholder="EN Name" value={newCategory.name.EN} onChange={e => updateNewCategoryField('EN', e.target.value)} className="w-full p-4 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none" required />
                    <input placeholder="RU Name" value={newCategory.name.RU} onChange={e => updateNewCategoryField('RU', e.target.value)} className="w-full p-4 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none" required />
                    <input placeholder="KZ Name" value={newCategory.name.KZ} onChange={e => updateNewCategoryField('KZ', e.target.value)} className="w-full p-4 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none" required />
                  </div>
                  <button type="submit" className="w-full bg-[#2E4032] text-white py-4 rounded-xl font-bold uppercase tracking-widest">Create Category</button>
                </form>
              </div>
            </div>
          )}

          {activeTab === 'products' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
              <div className="lg:col-span-2 space-y-8">
                <h2 className="text-4xl font-alice text-[#2E4032]">Inventory Master</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {products.map(p => (
                    <div key={p.id} className="flex items-center justify-between p-6 bg-gray-50 rounded-3xl group border border-transparent hover:border-[#AAB080]/20 transition-all">
                      <div className="flex items-center space-x-4">
                        <img src={p.image} className="w-16 h-16 object-cover rounded-2xl" alt={lp(p.name)} />
                        <div>
                          <h4 className="font-bold text-[#2E4032]">{lp(p.name)}</h4>
                          <p className="text-xs text-[#AAB080]">{p.categoryId ? lp(categories.find(c => c.id === p.categoryId)?.name || {EN:'',RU:'',KZ:''}) : 'No Category'}</p>
                        </div>
                      </div>
                      <button onClick={() => deleteProduct(p.id)} className="text-red-400 text-xs font-bold uppercase tracking-widest">Delete</button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-[#FCF9F2] p-10 rounded-[2.5rem] h-fit border border-[#AAB080]/20 shadow-sm">
                <h3 className="text-2xl font-alice text-[#2E4032] mb-10">Add New Offering</h3>
                <form onSubmit={handleAddProduct} className="space-y-6">
                  <div className="space-y-4">
                    <label className="text-[10px] uppercase tracking-widest font-bold text-[#AAB080]">Product Photograph</label>
                    <div className="relative group">
                      <div 
                        className={`w-full h-48 border-2 border-dashed rounded-3xl flex flex-col items-center justify-center transition-all cursor-pointer overflow-hidden ${newProduct.image ? 'border-transparent' : 'border-[#AAB080]/30 hover:border-[#E6B860]'}`}
                        onClick={() => fileInputRef.current?.click()}
                      >
                        {newProduct.image ? (
                          <img src={newProduct.image} alt="Preview" className="w-full h-full object-cover" />
                        ) : (
                          <>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-[#AAB080]/50 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                            <span className="text-[10px] text-[#AAB080] uppercase tracking-widest">Upload Portrait</span>
                          </>
                        )}
                      </div>
                      <input 
                        type="file" 
                        ref={fileInputRef}
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      {newProduct.image && (
                        <button 
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setNewProduct(prev => ({ ...prev, image: '' })); }}
                          className="absolute top-2 right-2 bg-white/80 backdrop-blur-sm p-2 rounded-full text-red-400 hover:text-red-600 shadow-sm"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <label className="text-[10px] uppercase tracking-widest font-bold text-[#AAB080]">Name (EN / RU / KZ)</label>
                    <input placeholder="Name EN" value={newProduct.name.EN} onChange={e => updateNewProductField('name', 'EN', e.target.value)} className="w-full p-3 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none" required />
                    <input placeholder="Name RU" value={newProduct.name.RU} onChange={e => updateNewProductField('name', 'RU', e.target.value)} className="w-full p-3 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none" required />
                    <input placeholder="Name KZ" value={newProduct.name.KZ} onChange={e => updateNewProductField('name', 'KZ', e.target.value)} className="w-full p-3 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none" required />
                  </div>
                  <div className="space-y-4">
                    <label className="text-[10px] uppercase tracking-widest font-bold text-[#AAB080]">Category & Price</label>
                    <select value={newProduct.categoryId} onChange={e => setNewProduct({...newProduct, categoryId: e.target.value})} className="w-full p-4 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none">
                      <option value="">Select Category</option>
                      {categories.map(c => <option key={c.id} value={c.id}>{lp(c.name)}</option>)}
                    </select>
                    <input type="number" placeholder="Price ₸" value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: e.target.value})} className="w-full p-4 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none" required />
                  </div>
                  <div className="space-y-4">
                    <label className="text-[10px] uppercase tracking-widest font-bold text-[#AAB080]">Short Essence (EN / RU / KZ)</label>
                    <input placeholder="Desc EN" value={newProduct.description.EN} onChange={e => updateNewProductField('description', 'EN', e.target.value)} className="w-full p-3 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none" required />
                    <input placeholder="Desc RU" value={newProduct.description.RU} onChange={e => updateNewProductField('description', 'RU', e.target.value)} className="w-full p-3 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none" required />
                    <input placeholder="Desc KZ" value={newProduct.description.KZ} onChange={e => updateNewProductField('description', 'KZ', e.target.value)} className="w-full p-3 rounded-xl border border-gray-200 focus:ring-1 focus:ring-[#AAB080] outline-none" required />
                  </div>
                  <button type="submit" className="w-full bg-[#2E4032] text-white py-4 rounded-xl font-bold uppercase tracking-widest">Publish Offering</button>
                </form>
              </div>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-10">
              <h2 className="text-4xl font-alice text-[#2E4032]">Patron Reflection Moderation</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {reviews.map(review => (
                  <div key={review.id} className="p-8 bg-[#FCF9F2] rounded-[2rem] border border-[#AAB080]/10 flex flex-col justify-between transition-transform hover:scale-[1.02]">
                    <div>
                      <div className="flex justify-between items-start mb-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-[#F6D989] rounded-full flex items-center justify-center font-bold text-[#2E4032]">{review.name.charAt(0)}</div>
                          <div>
                            <h4 className="font-bold text-[#2E4032]">{review.name}</h4>
                            <p className="text-[10px] text-[#AAB080]">Product: {lp(products.find(p => p.id === review.product_id)?.name || {EN:'Deleted',RU:'Удалено',KZ:'Өшірілген'})}</p>
                          </div>
                        </div>
                      </div>
                      <p className="text-sm text-[#2E4032]/70 italic leading-relaxed">"{review.text}"</p>
                    </div>
                    <div className="mt-8 flex justify-between items-center">
                      <span className="text-[10px] text-[#AAB080] uppercase tracking-widest">{new Date(review.created_at).toLocaleDateString()}</span>
                      <button onClick={() => deleteReview(review.id)} className="text-red-400 font-bold uppercase text-[10px] tracking-widest border border-red-400/20 px-3 py-1 rounded-full hover:bg-red-50">Remove Comment</button>
                    </div>
                  </div>
                ))}
                {reviews.length === 0 && <p className="text-center col-span-full py-20 text-[#AAB080] font-alice text-2xl">No reflections found.</p>}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Admin;
