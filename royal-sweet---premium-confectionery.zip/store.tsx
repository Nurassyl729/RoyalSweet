
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, Order, Review, MultilingualString, Category, User } from './types';

export type Language = 'EN' | 'RU' | 'KZ';

interface Translations {
  [key: string]: {
    [K in Language]: string;
  };
}

export const translations: Translations = {
  collections: { EN: 'Collections', RU: 'Коллекции', KZ: 'Топтамалар' },
  admin: { EN: 'Admin', RU: 'Админ', KZ: 'Админ' },
  reflections: { EN: 'Reflections', RU: 'Отзывы', KZ: 'Пікірлер' },
  boutique: { EN: 'Boutique', RU: 'Бутик', KZ: 'Бутик' },
  descriptor: { 
    EN: 'A sweet way to express emotions', 
    RU: 'Сладкий способ выразить чувства', 
    KZ: 'Сезімді білдірудің тәтті жолы' 
  },
  slogan: { 
    EN: 'Where tradition meets taste', 
    RU: 'Там, где встречаются традиция и вкус', 
    KZ: 'Дәстүр мен дәм үйлесімі' 
  },
  catalogTitle: { EN: 'Royal Sweets', RU: 'Royal Sweets', KZ: 'Royal Sweets' },
  catalogSub: { 
    EN: '"Collected with care for the moment. A delicate guide to the world of taste, emotions, and beautiful gestures."', 
    RU: '"Собрано с заботой о моменте. Деликатный проводник в мир вкуса, эмоций и красивых жестов."', 
    KZ: '"Сәт үшін қамқорлықпен жиналған. Дәм, эмоциялар мен әсем қимылдар әлеміне нәзік жолбасшы."' 
  },
  addToCart: { EN: 'Add to cart', RU: 'В корзину', KZ: 'Себетке салу' },
  viewDetails: { EN: 'View Details', RU: 'Подробнее', KZ: 'Толығырақ' },
  yourCollection: { EN: 'Your Collection', RU: 'Ваша коллекция', KZ: 'Сіздің топтамаңыз' },
  emptyCart: { EN: 'Your collection is empty.', RU: 'Ваша коллекция пуста.', KZ: 'Сіздің топтамаңыз бос.' },
  browseCollection: { EN: 'Browse Collection', RU: 'К покупкам', KZ: 'Топтаманы қарау' },
  totalValue: { EN: 'Total Gesture Value', RU: 'Общая ценность жеста', KZ: 'Жалпы құны' },
  proceedCheckout: { EN: 'Proceed to Checkout', RU: 'Оформить заказ', KZ: 'Тапсырыс беру' },
  fullName: { EN: 'Your Full Name', RU: 'Ваше полное имя', KZ: 'Толық аты-жөніңіз' },
  contactPhone: { EN: 'Contact Number', RU: 'Контактный телефон', KZ: 'Байланыс телефоны' },
  kaspiNumber: { EN: 'Kaspi Number', RU: 'Номер Kaspi', KZ: 'Kaspi нөмірі' },
  deliveryAddress: { EN: 'Delivery Residence', RU: 'Адрес доставки', KZ: 'Жеткізу мекенжайы' },
  completeOrder: { EN: 'Complete Order', RU: 'Завершить заказ', KZ: 'Тапсырысты аяқтау' },
  orderSuccess: { EN: 'A Gift in the Making', RU: 'Подарок готовится', KZ: 'Сыйлық дайындалуда' },
  paymentQueued: { EN: 'A payment link has been queued for your Kaspi account', RU: 'Ссылка на оплату отправлена на ваш Kaspi номер', KZ: 'Төлем сілтемесі сіздің Kaspi нөміріңізге жіберілді' },
  checkNotifications: { EN: 'Please check your Kaspi.kz app notifications shortly.', RU: 'Пожалуйста, проверьте уведомления в приложении Kaspi.kz.', KZ: 'Kaspi.kz қосымшасындағы хабарландыруларды тексеріңіз.' },
  patronReflections: { EN: 'Patron Reflections', RU: 'Отзывы ценителей', KZ: 'Тұтынушы пікірлері' },
  shareExperience: { EN: 'Share your experience', RU: 'Поделитесь впечатлениями', KZ: 'Әсеріңізбен бөлісіңіз' },
  postReflection: { EN: 'Post Reflection', RU: 'Оставить отзыв', KZ: 'Пікір қалдыру' },
  all: { EN: 'All', RU: 'Все', KZ: 'Барлығы' },
  remove: { EN: 'Remove', RU: 'Удалить', KZ: 'Өшіру' },
  refinementTitle: { EN: 'Refinement Meets Warmth', RU: 'Утонченность встречает тепло', KZ: 'Нәзіктік пен жылулық' },
  refinementDesc: { 
    EN: 'At Royal Sweet, every chocolate is a dialogue between British heritage and Kazakh soul. We bridge traditions to create moments of pure, aesthetic delight.', 
    RU: 'В Royal Sweet каждый шоколад — это диалог между британским наследием и казахской душой. Мы объединяем традиции, чтобы создавать моменты чистого эстетического восторга.', 
    KZ: 'Royal Sweet-те әрбір шоколад — британдық мұра мен қазақ жаны арасындағы диалог. Біз таза эстетикалық ләззат сәттерін жасау үшін дәстүрлерді байланыстырамыз.' 
  },
  account: { EN: 'Account', RU: 'Аккаунт', KZ: 'Аккаунт' },
  login: { EN: 'Sign In', RU: 'Войти', KZ: 'Кіру' },
  logout: { EN: 'Logout', RU: 'Выйти', KZ: 'Шығу' },
  profile: { EN: 'Profile', RU: 'Профиль', KZ: 'Профиль' },
  history: { EN: 'Gesture History', RU: 'История жестов', KZ: 'Әсерлер тарихы' },
};

interface AppContextType {
  products: Product[];
  categories: Category[];
  cart: CartItem[];
  orders: Order[];
  reviews: Review[];
  users: User[];
  currentUser: User | null;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  lp: (field: MultilingualString) => string;
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, delta: number) => void;
  clearCart: () => void;
  placeOrder: (customer: { name: string; phone: string; address: string; kaspi_number: string }) => void;
  addProduct: (product: Omit<Product, 'id'>) => void;
  deleteProduct: (id: number) => void;
  addCategory: (category: Omit<Category, 'id'>) => void;
  deleteCategory: (id: number) => void;
  deleteOrder: (id: number) => void;
  addReview: (review: Omit<Review, 'id' | 'created_at'>) => void;
  deleteReview: (id: number) => void;
  login: (email: string, pass: string) => boolean;
  register: (user: Omit<User, 'id'>) => void;
  logout: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const initialCategories: Category[] = [
  { id: 1, name: { EN: "Truffles", RU: "Трюфели", KZ: "Трюфельдер" } },
  { id: 2, name: { EN: "Macarons", RU: "Макароны", KZ: "Макарондар" } },
  { id: 3, name: { EN: "Pralines", RU: "Пралине", KZ: "Пралине" } },
  { id: 4, name: { EN: "Nougat", RU: "Нуга", KZ: "Нуга" } },
];

const initialProducts: Product[] = [
  {
    id: 1,
    categoryId: 1,
    name: { EN: "Golden Steppe Truffles", RU: "Трюфели Золотая Степь", KZ: "Алтын Дала Трюфельдері" },
    description: { 
      EN: "Handcrafted dark chocolate with a hint of honey and wild berries.", 
      RU: "Темный шоколад ручной работы с нотками меда и лесных ягод.", 
      KZ: "Бал мен жабайы жидектердің дәмі бар қолмен жасалған қара шоколад." 
    },
    longDescription: { 
      EN: "A tribute to the vast landscapes of Kazakhstan, these truffles combine premium British dark chocolate with local wildflower honey and sun-dried organic berries.", 
      RU: "Дань уважения бескрайним просторам Казахстана, эти трюфели сочетают в себе британский темный шоколад премиум-класса с местным медом и органическими ягодами.", 
      KZ: "Қазақстанның кең байтақ өлкесіне арналған бұл трюфельдер британдық қара шоколадты жергілікті балмен және кептірілген жидектермен үйлестіреді." 
    },
    price: 4500,
    image: "https://images.unsplash.com/photo-1548907604-f2b75a517b18?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 2,
    categoryId: 2,
    name: { EN: "London Fog Macarons", RU: "Макароны Лондонский Туман", KZ: "Лондон Тұманы Макарондары" },
    description: { 
      EN: "Earl Grey infused shells with a delicate lavender cream filling.", 
      RU: "Макароны с добавлением чая Эрл Грей и нежным лавандовым кремом.", 
      KZ: "Эрл Грей шайы қосылған және нәзік лаванда кремі толтырылған макарондар." 
    },
    longDescription: { 
      EN: "Inspired by the classic British tea, these macarons offer a sophisticated citrus and floral profile. The shells are light as air, yielding to a silky ganache.", 
      RU: "Вдохновленные классическим британским чаем, эти макароны обладают утонченным цитрусовым и цветочным профилем.", 
      KZ: "Классикалық британдық шайдан шабыттанған бұл макарондар цитрустық және гүлді хош иіс береді." 
    },
    price: 3800,
    image: "https://images.unsplash.com/photo-1558326567-98ae2405596b?auto=format&fit=crop&q=80&w=800"
  }
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [categories, setCategories] = useState<Category[]>(initialCategories);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('rs_lang') as Language) || 'EN';
  });

  useEffect(() => {
    localStorage.setItem('rs_lang', language);
  }, [language]);

  const t = (key: string): string => {
    return translations[key] ? translations[key][language] : key;
  };

  const lp = (field: MultilingualString): string => {
    if (!field) return '';
    return field[language] || field['EN'] || '';
  };

  useEffect(() => {
    const savedCart = sessionStorage.getItem('rs_cart');
    const savedOrders = localStorage.getItem('rs_orders');
    const savedReviews = localStorage.getItem('rs_reviews');
    const savedProducts = localStorage.getItem('rs_products');
    const savedCategories = localStorage.getItem('rs_categories');
    const savedUsers = localStorage.getItem('rs_users');
    const savedAuth = sessionStorage.getItem('rs_auth_user');

    if (savedCart) setCart(JSON.parse(savedCart));
    if (savedOrders) setOrders(JSON.parse(savedOrders));
    if (savedReviews) setReviews(JSON.parse(savedReviews));
    if (savedProducts) setProducts(JSON.parse(savedProducts));
    if (savedCategories) setCategories(JSON.parse(savedCategories));
    if (savedUsers) setUsers(JSON.parse(savedUsers));
    if (savedAuth) setCurrentUser(JSON.parse(savedAuth));
  }, []);

  useEffect(() => sessionStorage.setItem('rs_cart', JSON.stringify(cart)), [cart]);
  useEffect(() => localStorage.setItem('rs_orders', JSON.stringify(orders)), [orders]);
  useEffect(() => localStorage.setItem('rs_reviews', JSON.stringify(reviews)), [reviews]);
  useEffect(() => localStorage.setItem('rs_products', JSON.stringify(products)), [products]);
  useEffect(() => localStorage.setItem('rs_categories', JSON.stringify(categories)), [categories]);
  useEffect(() => localStorage.setItem('rs_users', JSON.stringify(users)), [users]);
  useEffect(() => {
    if (currentUser) {
      sessionStorage.setItem('rs_auth_user', JSON.stringify(currentUser));
    } else {
      sessionStorage.removeItem('rs_auth_user');
    }
  }, [currentUser]);

  const addToCart = (product: Product, quantity: number = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item);
      }
      return [...prev, { product, quantity }];
    });
  };

  const removeFromCart = (productId: number) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateQuantity = (productId: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.product.id === productId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const clearCart = () => setCart([]);

  const placeOrder = (customer: { name: string; phone: string; address: string; kaspi_number: string }) => {
    const total = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    const newOrder: Order = {
      id: Date.now(),
      user_id: currentUser?.id,
      customer_name: customer.name,
      phone: customer.phone,
      kaspi_number: customer.kaspi_number,
      address: customer.address,
      total_price: total,
      created_at: new Date().toISOString(),
      items: cart.map(item => ({
        id: Math.random(),
        product_id: item.product.id,
        quantity: item.quantity,
        price: item.product.price,
        name: lp(item.product.name)
      }))
    };
    setOrders(prev => [newOrder, ...prev]);
    clearCart();
  };

  const addProduct = (p: Omit<Product, 'id'>) => {
    setProducts(prev => [...prev, { ...p, id: Date.now() }]);
  };

  const deleteProduct = (id: number) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const addCategory = (c: Omit<Category, 'id'>) => {
    setCategories(prev => [...prev, { ...c, id: Date.now() }]);
  };

  const deleteCategory = (id: number) => {
    setCategories(prev => prev.filter(c => c.id !== id));
    setProducts(prev => prev.map(p => p.categoryId === id ? { ...p, categoryId: undefined } : p));
  };

  const deleteOrder = (id: number) => {
    setOrders(prev => prev.filter(o => o.id !== id));
  };

  const addReview = (r: Omit<Review, 'id' | 'created_at'>) => {
    setReviews(prev => [...prev, { ...r, id: Date.now(), created_at: new Date().toISOString() }]);
  };

  const deleteReview = (id: number) => {
    setReviews(prev => prev.filter(r => r.id !== id));
  };

  const login = (email: string, pass: string) => {
    const user = users.find(u => u.email === email && u.password === pass);
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  };

  const register = (user: Omit<User, 'id'>) => {
    const newUser = { ...user, id: Date.now() };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
  };

  const logout = () => {
    setCurrentUser(null);
  };

  return (
    <AppContext.Provider value={{
      products, categories, cart, orders, reviews, users, currentUser, language, setLanguage, t, lp,
      addToCart, removeFromCart, updateQuantity, clearCart, placeOrder,
      addProduct, deleteProduct, addCategory, deleteCategory, deleteOrder, addReview, deleteReview,
      login, register, logout
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useStore must be used within AppProvider");
  return context;
};
